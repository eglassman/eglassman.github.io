# Supplemental Materials

`appendix.pdf` is the appendix of the paper, which contains additional details and alternate presentations of results.

For code, see <https://github.com/dtak/interactive-reconstruction>.
